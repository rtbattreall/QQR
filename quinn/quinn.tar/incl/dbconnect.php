<?
$DBuser="quinn";
$DBpass="0u1nnr39Or$";
$host="localhost";
$base="https://www.quinnsreporting.com";
?>
